package com.exams;

class FileIOException extends Exception {
    public FileIOException(String message) {
        super(message);
    }
}
